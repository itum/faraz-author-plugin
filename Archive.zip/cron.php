<?php
require 'add-content.php';
stp_check_for_new_rss_items();